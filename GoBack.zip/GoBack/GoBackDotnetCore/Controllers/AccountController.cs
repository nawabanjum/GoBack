﻿using GoBackDotnetCore.Models;
using GoBackDotnetCore.Tools;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;


namespace GoBackDotnetCore.Controllers
{

    public class AccountController : Controller
    {
        // GET: Account
        public ActionResult Index()
        {
            return View();
        }
        private  goBAK.Seguridad.CUsuarios miUsuario = new goBAK.Seguridad.CUsuarios();

        public AccountController()
        {
          

        }
        private ActionResult RedirectToLocal(string returnUrl, string actionName = "home")
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction("Index", actionName);
            }
        }
        
        [HttpGet]
        public ActionResult panel(string returnUrl)
        {
            ViewBag.Login = true;
            return View();
        }
        public ActionResult changepassword(string UserEmail)
        {
            ViewBag.UserEmail = UserEmail;
            return View();
        }
        [HttpPost]
        public ActionResult changepassword(string UserEMail, string oldPassword, string newPassword)
        {
            return View();
        }
        [HttpGet]
        public ActionResult Login(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }
        [HttpPost]
        public async Task<ActionResult> Login(string Email, string Password, string returnUrl = null)
        {
            try
            {
                string msgError = string.Empty;
                var res = miUsuario.FillID(ref msgError, Email, Password);
                if (res)
                {
                    if (miUsuario.Activo == false)
                    {
                        ViewBag.Message = "INACTIVE USER";
                        ViewBag.Login = false;
                        return View();
                    }
                    if (miUsuario.Reset)
                    {
                        RedirectToAction("changepassword");
                    }
                    
                    //Response.Write(miUsuario.iD.ToString());
                    //Response.Write(miUsuario.Apellido);
                    //Response.Write(miUsuario.Nombre);
                    //Response.Write(miUsuario.Documento);
                    //Response.Write(miUsuario.Email);
                    //Response.Write(miUsuario.iDDepartamento.ToString());
                    //Response.Write(miUsuario.Activo.ToString());
                    //Response.Write(miUsuario.Reset.ToString());
                    return RedirectToLocal(returnUrl);
                }
                else
                {
                    ViewBag.Message = msgError;
                    ViewBag.Login = false;
                    return View();
                }

            }
            catch (Exception ex)
            {

                throw;
            }
        }
        public ActionResult RecoverPassword()
        {
            ViewBag.Message = "";
            return View();
        }
        public ActionResult SendEmail(string UserEmail)
        {
            string msgError = string.Empty;
            //var timeStamp = DateTime.Now.DateTimeToUnixTimeStamp();
            // OtpManager otpManager = new OtpManager();
            // var code = otpManager.GetTotpCode(($"{Consts.TotpSecretKey}_#^&{UserEmail}"), 300, timeStamp);
            string code = miUsuario.GetCode(ref msgError, UserEmail);

            if (code == string.Empty)
            {
                ViewBag.Message = "MAIL NOT REGISTERED";
                return View();
            }
            else
           
            {
                //string adress = $"http://localhost:1381/account/ConfirmCode?timestamp={timeStamp}&useremail={UserEmail}";
                var EmailBody = $"<p>Your recovery Code is: {code}</p>";
                //EmailBody += "<p>Click on the link below to recover the password</p>";
                //EmailBody += $"<a href='{adress}' class='btn btn-info'>Password recovery</a>";
                var result = EmailService.SendEmail(UserEmail, "recovery password", EmailBody);
                ViewBag.Result = result;
            }
           
            ViewBag.code = code;
            ViewBag.UserEmail = UserEmail;
            return View("ConfirmCode");
        }
        public ActionResult ConfirmCode( )
        {
           
           
            return View();
        }
        [HttpPost]
        public ActionResult ResponseConfirmCode(string code,string sendedCode, string password, string useremail)
        {
            string msgError = string.Empty;
            //OtpManager otpManager = new OtpManager();
            //var otpcode = otpManager.GetTotpCode(($"{Consts.TotpSecretKey}_#^&{useremail}"), 300, timestamp);
           
            if (code == sendedCode)
            {
                if (miUsuario.UpdatePassword(ref msgError, code, useremail, password, 0) == -1)
                    ViewBag.Message = msgError;
                else
                    ViewBag.Message="SUCCESSFUL OPERATION MESSAGE";
            }
            else
            {
                ViewBag.Message = "incorrect cod";
            }
            
            return View();
        }

    }
}