﻿using OtpNet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace GoBackDotnetCore.Tools
{
    public class OtpManager
    {
        public OtpManager() { }
        public string GetTotpCode(string secretKey, int second, long date, int toptpSize = 8)
        {

            var totp = new Totp(secretKey.GetBytes(), second, totpSize: toptpSize);
            //
            var t = totp.ComputeTotp(date.UnixTimeStampToDateTime());

            return t;
        }
    }
}