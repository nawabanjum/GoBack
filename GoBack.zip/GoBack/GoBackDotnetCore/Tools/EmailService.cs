﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace GoBackDotnetCore.Tools
{
    public static class EmailService
    {
        public static bool SendEmail(string EmailAddress, string subject, string body)
        {
            var result = false;
            string sender = "test@gmail.com";
            string senderPassword = "12345";
            try
            {
                MailMessage m = new MailMessage
                    (
                    new MailAddress(sender),
                    new MailAddress(EmailAddress)
                    );
                m.Subject = subject;
                m.Body = body;
                m.IsBodyHtml = true;
                SmtpClient smtp = new SmtpClient("smtp.gmail.com");
                smtp.EnableSsl = true;
                smtp.UseDefaultCredentials = true;
                smtp.Port = 587;
                smtp.Credentials = new NetworkCredential(sender, senderPassword);
                smtp.Send(m);
                result = true;
            }
            catch (Exception)
            {
                result = false;
            }
            return result;
        }
    }
}