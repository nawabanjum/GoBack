﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace GoBackDotnetCore.Tools
{
    public static class Extensions
    {
        public static T ChangeType<T>(this object value)
        {
            var t = typeof(T);

            if (t.IsGenericType && t.GetGenericTypeDefinition().Equals(typeof(Nullable<>)))
            {
                if (value == null)
                {
                    return default(T);
                }

                t = Nullable.GetUnderlyingType(t);
            }

            return (T)Convert.ChangeType(value, t);
        }
        public static string GetMD5(this string input)
        {
            // Use input string to calculate MD5 hash
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                // Convert the byte array to hexadecimal string
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    sb.Append(hashBytes[i].ToString("X2"));
                }
                return sb.ToString();
            }
        }
        
         public static byte[] GetBytes(this string secretKey)
        {
            return Encoding.ASCII.GetBytes(secretKey);
        }

        public static long DateTimeToUnixTimeStamp(this DateTime dateTime)
        {
            TimeSpan res;
            // Unix timestamp is seconds past epoch
            System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
            if (dateTime.Kind == DateTimeKind.Utc)
                res = dateTime - dtDateTime;
            else
                res = dateTime - dtDateTime.ToUniversalTime();
            return (long)res.TotalSeconds;
        }
        public static DateTime UnixTimeStampToDateTime(this long timeStamp)
        {

            System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);

            return dtDateTime.AddSeconds(timeStamp);
        }

    }
}